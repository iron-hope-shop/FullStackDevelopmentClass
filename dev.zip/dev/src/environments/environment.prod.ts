export const environment = {
  production: true,
  api_url: 'https://q-a-example-loopback-api.herokuapp.com'
};
